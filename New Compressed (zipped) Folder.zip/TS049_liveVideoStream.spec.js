const { test, expect } = require('@playwright/test');
const TestHelpers = require('../utils/test-helpers');

test.describe('Dashcam refresh', () => {
    let config;
    let helpers;

  test.beforeAll(async ({ browser }) => {
        const page = await browser.newPage();
        helpers = new TestHelpers(page);
        config = await helpers.getConfig();
        await page.close();
    });

  test.beforeEach(async ({ page }) => {
        helpers = new TestHelpers(page);
        await helpers.clearStorageAndSetTimeouts();
        
        // Set timeouts
        test.setTimeout(600000); // 10 minutes for long test
    });

    test('refresh dashcam', async ({ page }) => {
        const helpers = new TestHelpers(page);
        config = await helpers.getConfig();

        // Use fast login helper which handles stored auth vs fresh login automatically
        await helpers.loginAndNavigateToPage(config.urls.fleetDashcamDashboard2);

        // Click on Dashcam accordion header to expand menu
        const dashcamAccordion = page.locator('#bottom-nav-dashcam .accordion__header');
        await expect(dashcamAccordion).toBeVisible();
        await dashcamAccordion.click();

        // Wait for accordion to expand
        await page.waitForTimeout(1000);

        // Click on Live Video Stream option
        const liveVideoStreamOption = page.locator('#bottom-nav-live-stream');
        await expect(liveVideoStreamOption).toBeVisible();
        await liveVideoStreamOption.click({ force: true });

        await page.waitForTimeout(4000);

        // Wait for the live-video-stream container to be visible
        await expect(page.locator(config.selectors.dashcam.liveVideoStreamPanel)).toBeVisible();

        // Click on the Select2 dropdown to open options
        await page.locator('#live-video-stream-panel .select2-selection__rendered').click();
        
        const firstOption = page.locator('.select2-results__option').first();
        await expect(firstOption).toBeVisible();
        await firstOption.click({ force: true });

        // Intercept the API call before clicking the button
        const liveVideoStreamPromise = page.waitForResponse(response => 
            response.url().includes('SendDashcamLiveCommand.php') && response.request().method() === 'POST'
        );

        // Check "Dash View" and "Cabin View" checkboxes
        await page.locator(config.selectors.dashcam.dashViewCheckbox).check({ force: true });
        await page.locator(config.selectors.dashcam.cabinViewCheckbox).check({ force: true });

        // Click on Submit button
        await page.locator(config.selectors.dashcam.liveVideoStreamSubmitBtn).click({ force: true });

        // Wait for the API call and verify status
        const response = await liveVideoStreamPromise;
        expect(response.status()).toBe(200);
    });
});